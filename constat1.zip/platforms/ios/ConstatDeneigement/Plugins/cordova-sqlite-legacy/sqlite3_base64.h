#include "sqlite3.h"

#ifdef __cplusplus
extern "C" {
#endif

int sqlite3_base64_init(sqlite3 * db);

#ifdef __cplusplus
}
#endif
