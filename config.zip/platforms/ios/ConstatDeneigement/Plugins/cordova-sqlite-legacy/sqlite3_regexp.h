#include "sqlite3.h"

#ifdef __cplusplus
extern "C" {
#endif

int sqlite3_regexp_init(sqlite3 * db, const char ** err);

#ifdef __cplusplus
}
#endif
